#include "pid.h"


PID *PID_Hardware = NULL;

PID *PID_use()
{
    if (PID_Hardware == NULL)
    {
        PID_Hardware = new PID();
    }

    return PID_Hardware;
}

void Release_PID_Hardware()
{
    if (PID_Hardware == NULL)
    {
        return;
    }

    delete PID_Hardware;
    PID_Hardware = NULL;
}



#define ABS(x)		((x>0)? x: -x) 
void abs_limit(float *a, float ABS_MAX){
    if(*a > ABS_MAX)
        *a = ABS_MAX;
    if(*a < -ABS_MAX)
        *a = -ABS_MAX;
}

float PID::pid_calc(pid_rm_t* pid, float get, float set){
    pid->get[NOW] = get;
    pid->set[NOW] = set;
    pid->err[NOW] = set - get;	//set - measure
    if (pid->max_err != 0 && ABS(pid->err[NOW]) >  pid->max_err  )
			return 0;
		if (pid->deadband != 0 && ABS(pid->err[NOW]) < pid->deadband)
			return 0;
    
    // if(pid->pid_mode == POSITION_PID) //位置式p
    // {
        pid->pout = pid->p * pid->err[NOW];
        pid->iout += pid->i * pid->err[NOW];
        pid->dout = pid->d * (pid->err[NOW] - pid->err[LAST] );
        abs_limit(&(pid->iout), pid->IntegralLimit);
        pid->pos_out = pid->pout + pid->iout + pid->dout;
        abs_limit(&(pid->pos_out), pid->MaxOutput);
        pid->last_pos_out = pid->pos_out;	//update last time 
   // }
    // else if(pid->pid_mode == DELTA_PID)//增量式P
    // {
    //     pid->pout = pid->p * (pid->err[NOW] - pid->err[LAST]);
    //     pid->iout = pid->i * pid->err[NOW];
    //     pid->dout = pid->d * (pid->err[NOW] - 2*pid->err[LAST] + pid->err[LLAST]);
        
    //     abs_limit(&(pid->iout), pid->IntegralLimit);
    //     pid->delta_u = pid->pout + pid->iout + pid->dout;
    //     pid->delta_out = pid->last_delta_out + pid->delta_u;
    //     abs_limit(&(pid->delta_out), pid->MaxOutput);
    //     pid->last_delta_out = pid->delta_out;	//update last time
    // }
    
    pid->err[LLAST] = pid->err[LAST];
    pid->err[LAST] = pid->err[NOW];
    pid->get[LLAST] = pid->get[LAST];
    pid->get[LAST] = pid->get[NOW];
    pid->set[LLAST] = pid->set[LAST];
    pid->set[LAST] = pid->set[NOW];
  //  return pid->pid_mode==POSITION_PID ? pid->pos_out : pid->delta_out;
  return  pid->pos_out ;
//	
}
       

/*pid总体初始化-----------------------------------------------------------------*/
void PID::PID_struct_init(
    pid_rm_t* pid,
    float mode,
    float maxout,
    float intergral_limit,
    
    float 	kp, 
    float 	ki, 
    float 	kd)
{
    pid->p=kp;
    pid->i=ki;
    pid->d=kd;
    pid->pid_mode=mode;
    pid->MaxOutput=maxout;
    pid->IntegralLimit=intergral_limit;	
}

// void PID::LQR_Balance()
// {



// }



