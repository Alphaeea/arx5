
#include "CANFrameParser.h"

CANFrameParser::CANFrameParser() {}

CANFrameParser::~CANFrameParser() {}

void CANFrameParser::parse_frame(can_frame_t *) {}
