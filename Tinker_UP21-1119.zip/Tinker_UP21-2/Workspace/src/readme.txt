1.CAN0&CAN1 done

2021 1007 1700
1.CAN1接收测试 done  ROS_WARN("%d",motors_can1[0].total_angle);

2021 1007 2024
1.Dbus 获取done

2021 1007 2244
1.Dbus 完美

2021 1008 1913
1.结构体复用 done  handle

2021 1009 1016
1.imu done

2021 1009 2113
1.CAN rebuild   

2021 1009 2303
1.修订include 路径

2021 1010 1551
1.自定义PID done
2.遥控器控制双环PID done

2021 1010 2012
1.底盘解算更新

2021 1013 1914
1.MIT motor can_receive done

2021 1013 2031
1.MIT moto control done

2021 1014 1634
1.ROS 平衡步兵done

2021 1014 1722
1.参数修正 KP 变为正  ki注意方向

2021 1020 1915
1.Dreame 电机发送done

2021 1021 1650
1.Dreame 电机发送 接收done

2021 1021 1706
1.代码整理 ID可更改 注意[8]数组中赋上 电机地址

2021 1110 2115
1.ARX-5 ID 1 2 3 位置控制 done

2021 1111 1351
1.遥控器保护模式 done



##############################
cansend can0 0701010F#3A39463730323211
            07类型 01 设置id 01 主机id 0F当前id # 电机地址


  |||||
//|||||\\
ID1    ID2
伸展
ID1 -1188 
ID2 -725   7584
ID3 -1887 -1857
ID4 -5851

//0
ID1 -1196 
ID2 -768
ID3 -6701
ID4  1574
