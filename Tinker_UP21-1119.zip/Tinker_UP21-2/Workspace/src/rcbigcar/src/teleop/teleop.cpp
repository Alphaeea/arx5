
 
#include "ros/ros.h"  
//ros/ros.h是一个实用的头文件，它引用了ROS系统中大部分常用的头文件  
#include "std_msgs/String.h"  
//std_msgs/String存放在std_msgs package里，由String.msg文件自动生成的头文件
#include <control_msgs/FollowJointTrajectoryAction.h>  
#include <control_msgs/FollowJointTrajectoryActionGoal.h>
#include <control_msgs/FollowJointTrajectoryGoal.h>
#include <trajectory_msgs/JointTrajectory.h>
#include <trajectory_msgs/JointTrajectoryPoint.h>

#include "/home/dyh/Tinker_UP21-2/Workspace/src/rcbigcar/src/robot/hardware.h"

//回调函数，当message topic消息到达后会调用此函数  control_msgs/FollowJointTrajectoryActionGoal
void execute(const  control_msgs::FollowJointTrajectoryActionGoal::ConstPtr& msg)
{  
    ROS_WARN("start:%lf ",msg->goal.trajectory.points[0].positions[0] );
    
    // Hardware()->motion_angle[0]=msg->goal.trajectory.points[29].positions[1];
    std::cout << "points[0]: "  
             << "[" << msg->goal.trajectory.points[0].positions[0]  
             << "," << msg->goal.trajectory.points[0].positions[1]  
             << "," << msg->goal.trajectory.points[0].positions[2]  
             << "," << msg->goal.trajectory.points[0].positions[3]  
             << "," << msg->goal.trajectory.points[0].positions[4]  
             << "," << msg->goal.trajectory.points[0].positions[5]  
             << "]" << std::endl ;
 
    std::cout << "points[1]: "  
             << "[" << msg->goal.trajectory.points[1].positions[0] * 180.0 / 3.1415926535  
             << "," << msg->goal.trajectory.points[1].positions[1] * 180.0 / 3.1415926535 
             << "," << msg->goal.trajectory.points[1].positions[2] * 180.0 / 3.1415926535   
             << "," << msg->goal.trajectory.points[1].positions[3] * 180.0 / 3.1415926535   
             << "," << msg->goal.trajectory.points[1].positions[4] * 180.0 / 3.1415926535   
             << "," << msg->goal.trajectory.points[1].positions[5] * 180.0 / 3.1415926535   
             << "]" << std::endl ;
 
std::cout << "points[2]: "  
             << "[" << msg->goal.trajectory.points[2].positions[0]  
             << "," << msg->goal.trajectory.points[2].positions[1]  
             << "," << msg->goal.trajectory.points[2].positions[2]  
             << "," << msg->goal.trajectory.points[2].positions[3]  
             << "," << msg->goal.trajectory.points[2].positions[4]  
             << "," << msg->goal.trajectory.points[2].positions[5]  
             << "]" << std::endl ;
 
 
std::cout << "points[3]: "  
             << "[" << msg->goal.trajectory.points[3].positions[0]  
             << "," << msg->goal.trajectory.points[3].positions[1]  
             << "," << msg->goal.trajectory.points[3].positions[2]  
             << "," << msg->goal.trajectory.points[3].positions[3]  
             << "," << msg->goal.trajectory.points[3].positions[4]  
             << "," << msg->goal.trajectory.points[3].positions[5]  
             << "]" << std::endl ;
 
std::cout << "points[4]: "  
             << "[" << msg->goal.trajectory.points[4].positions[0]  
             << "," << msg->goal.trajectory.points[4].positions[1]  
             << "," << msg->goal.trajectory.points[4].positions[2]  
             << "," << msg->goal.trajectory.points[4].positions[3]  
             << "," << msg->goal.trajectory.points[4].positions[4]  
             << "," << msg->goal.trajectory.points[4].positions[5]  
             << "]" << std::endl ;
 
 std::cout << "points[5]: "  
             << "[" << msg->goal.trajectory.points[5].positions[0]  
             << "," << msg->goal.trajectory.points[5].positions[1]  
             << "," << msg->goal.trajectory.points[5].positions[2]  
             << "," << msg->goal.trajectory.points[5].positions[3]  
             << "," << msg->goal.trajectory.points[5].positions[4]  
             << "," << msg->goal.trajectory.points[5].positions[5]  
             << "]" << std::endl ;    
 
std::cout << "points[6]: "  
             << "[" << msg->goal.trajectory.points[6].positions[0]  
             << "," << msg->goal.trajectory.points[6].positions[1]  
             << "," << msg->goal.trajectory.points[6].positions[2]  
             << "," << msg->goal.trajectory.points[6].positions[3]  
             << "," << msg->goal.trajectory.points[6].positions[4]  
             << "," << msg->goal.trajectory.points[6].positions[5]  
             << "]" << std::endl ;
 
std::cout << "points[27]: "  
             << "[" << msg->goal.trajectory.points[27].positions[0]  
             << "," << msg->goal.trajectory.points[27].positions[1]  
             << "," << msg->goal.trajectory.points[27].positions[2]  
             << "," << msg->goal.trajectory.points[27].positions[3]  
             << "," << msg->goal.trajectory.points[27].positions[4]  
             << "," << msg->goal.trajectory.points[27].positions[5]  
             << "]" << std::endl ;
 
std::cout << "points[28]: "  
             << "[" << msg->goal.trajectory.points[28].positions[0]  
             << "," << msg->goal.trajectory.points[28].positions[1]  
             << "," << msg->goal.trajectory.points[28].positions[2]  
             << "," << msg->goal.trajectory.points[28].positions[3]  
             << "," << msg->goal.trajectory.points[28].positions[4]  
             << "," << msg->goal.trajectory.points[28].positions[5]  
             << "]" << std::endl ;
 
std::cout << "points[29]: "  
             << "[" << msg->goal.trajectory.points[29].positions[0] * 180.0 / 3.1415926535   
             << "," << msg->goal.trajectory.points[29].positions[1] * 180.0 / 3.1415926535   
             << "," << msg->goal.trajectory.points[29].positions[2] * 180.0 / 3.1415926535   
             << "," << msg->goal.trajectory.points[29].positions[3] * 180.0 / 3.1415926535   
             << "," << msg->goal.trajectory.points[29].positions[4] * 180.0 / 3.1415926535   
             << "," << msg->goal.trajectory.points[29].positions[5] * 180.0 / 3.1415926535   
             << "]" << std::endl ;
 
}  
  
  
int main(int argc, char **argv)  
{  
    
    //初始化ROS，注意：名称必须唯一  
    ros::init(argc, argv, "teleop");  
  //监听/arm_controller/follow_joint_trajectory/goal话题发布的消息
    //设置节点进程句柄  
    ros::NodeHandle n;  
  
    //参数一为订阅的话题名称（/arm_controller/follow_joint_trajectory/goal）；  
    //参数二是消息缓存队列，这里设置为1000，即缓存了1000个消息后，如果由新的消息到达，则开始丢弃先前接收的消息；  
    //参数三为当收到消息后调用的函数名称（execute）  
    ros::Subscriber sub = n.subscribe("/arm_controller/follow_joint_trajectory/goal", 1000, execute);  
      
    //ros::spin()进入自循环，可以尽可能快的调用消息回调函数  
    ros::spin();    
    return 0;  
}  