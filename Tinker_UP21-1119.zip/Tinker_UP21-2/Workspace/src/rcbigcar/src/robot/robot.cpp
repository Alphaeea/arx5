#include "ros/ros.h"  
//ros/ros.h是一个实用的头文件，它引用了ROS系统中大部分常用的头文件  
#include "std_msgs/String.h"
#include "chassis.h"
#include "motion.h"
#include "hardware.h"
#include "dbus.h"
#include "pid.h"

#include <control_msgs/FollowJointTrajectoryAction.h>  
#include <control_msgs/FollowJointTrajectoryActionGoal.h>
#include <control_msgs/FollowJointTrajectoryGoal.h>
#include <trajectory_msgs/JointTrajectory.h>
#include <trajectory_msgs/JointTrajectoryPoint.h>

void execute(const  control_msgs::FollowJointTrajectoryActionGoal::ConstPtr& msg)
{  
    Hardware()->motion_angle[0]=msg->goal.trajectory.points[29].positions[0] * 180.0 / 3.1415926535 ;
	Hardware()->motion_angle[1]=msg->goal.trajectory.points[29].positions[1] * 180.0 / 3.1415926535 ;
	Hardware()->motion_angle[2]=msg->goal.trajectory.points[29].positions[2] * 180.0 / 3.1415926535 ;
	Hardware()->motion_angle[3]=msg->goal.trajectory.points[29].positions[3] * 180.0 / 3.1415926535 ;
	Hardware()->motion_angle[4]=msg->goal.trajectory.points[29].positions[4] * 180.0 / 3.1415926535 ;
	Hardware()->motion_angle[5]=msg->goal.trajectory.points[29].positions[5] * 180.0 / 3.1415926535 ;
	
	// ROS_WARN("motion_angle0:%lf",Hardware()->motion_angle[0]);
    // ROS_WARN("motion_angle1:%lf",Hardware()->motion_angle[1]);
    // ROS_WARN("motion_angle2:%lf",Hardware()->motion_angle[2]);
    // ROS_WARN("motion_angle3:%lf",Hardware()->motion_angle[3]);

    std::cout << "points[29]: "  
             << "[" << Hardware()->motion_angle[0] 
             <<  "||||0000000000||||" 
             << "]" << std::endl 
			 << "[" << Hardware()->motion_angle[1] 
             <<  "||||0000000000||||" 
             << "]" << std::endl
			 << "[" << Hardware()->motion_angle[2] 
             <<  "||||0000000000||||" 
             << "]" << std::endl
			 << "[" << Hardware()->motion_angle[3] 
             <<  "||||0000000000||||" 
             << "]" << std::endl
			 << "[" << Hardware()->motion_angle[4] 
             <<  "||||0000000000||||" 
             << "]" << std::endl
			 << "[" << Hardware()->motion_angle[5] 
             <<  "||||0000000000||||" 
             << "]" << std::endl;
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "robot");

	ros::NodeHandle nh;

	///////////////////////////////////////
	ros::Subscriber sub = nh.subscribe("/arm_controller/follow_joint_trajectory/goal", 1000, execute);
	///////////////////////////////////////

	// We run the ROS loop in a separate thread as external calls, such
	// as service callbacks loading controllers, can block the (main) control loop
	ros::AsyncSpinner spinner(1);
	spinner.start();

	// set process priority
	struct sched_param params{.sched_priority = 98};
  	if (sched_setscheduler(0, SCHED_FIFO, &params) == -1)
    	ROS_ERROR("Set scheduler failed, RUN THIS NODE AS SUPER USER.\n");

	//Create Nodes
	Chassis chassis;
	Motion motion;
    Hardware()->CanComm_ControlCmd(0x01,0xFC);
   // sleep(20);

	ros::Rate loop_rate(ROBOT_SAMPLING_RATE);

	DBus_Use()->init();
 //	Hardware()->CanComm_ControlCmd(0x02,0xFC);   
	Hardware()->model4_CanComm_ControlCmd(0x01);
	Hardware()->model4_CanComm_ControlCmd(0x02);
	Hardware()->model4_CanComm_ControlCmd(0x03);
	
	sleep(3);
	ROS_WARN("start:%f ",666);
	Hardware()->model3_CanComm_ControlCmd(0x01);
	Hardware()->model3_CanComm_ControlCmd(0x02);
	Hardware()->model3_CanComm_ControlCmd(0x03);
	Hardware()->model3_CanComm_ControlCmd(0x04);
	//Process Jobs

	while (ros::ok())
//	while (1)
	{

		DBus_Use()->read();
		DBus_Use()->getData();

		//Update Subnodes	  
		chassis.update();
		motion.update();
    
		//Update Hardware
		Hardware()->update();
        
		//Loop
		loop_rate.sleep();
	}

	//Release Hardware
	ReleaseHardware();
	Release_DB_Hardware();

	Release_PID_Hardware();

	return 0;
}
