#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#include <ros/ros.h>
#include <vector>
#include "libcan/SocketCAN.h"
#include "config.h"
#include "dbus.h"
////////////////////Hardware Level//////////////////////////



 #define P_MIN -12.5f
 #define P_MAX 12.5f
 #define V_MIN -20.9f
 #define V_MAX 20.9f
 #define KP_MIN 0.0f
 #define KP_MAX 500.0f
 #define KD_MIN 0.0f
 #define KD_MAX 5.0f
 #define T_MIN -24.8f
 #define T_MAX 24.8f
 #define LIMIT_MIN_MAX(x,min,max) (x) = (((x)<=(min))?(min):(((x)>=(max))?(max):(x)))

typedef enum
{
    CAN_TxPY12V_ID = 0x200, //云台12V发送ID
    CAN_TxPY24V_ID = 0x1FF, //云台12V发送ID
    //	CAN_Pitch_ID 	= 0x201,			//云台Pitch
    //	CAN_Yaw_ID   	= 0x203,			//云台Yaw
    CAN_YAW_FEEDBACK_ID = 0x205, //云台Yaw24v
    CAN_PIT_FEEDBACK_ID = 0x206, //云台Yaw24v
    CAN_POKE_FEEDBACK_ID = 0x207,
    CAN_ZGYRO_RST_ID = 0x404,
    CAN_ZGYRO_FEEDBACK_MSG_ID = 0x401,
    CAN_MotorLF_ID = 0x041,         //左前
    CAN_MotorRF_ID = 0x042,         //右前
    CAN_MotorLB_ID = 0x043,         //左后
    CAN_MotorRB_ID = 0x044,         //右后
    CAN_EC60_four_ID = 0x200,       //EC60接收程序
    CAN_backLeft_EC60_ID = 0x203,   //ec60
    CAN_frontLeft_EC60_ID = 0x201,  //ec60
    CAN_backRight_EC60_ID = 0x202,  //ec60
    CAN_frontRight_EC60_ID = 0x204, //ec60
    CAN_3510Moto_ALL_ID = 0x200,
    CAN_3510Moto1_ID = 0x201,
    CAN_3510Moto2_ID = 0x202,
    CAN_3510Moto3_ID = 0x203,
    CAN_3510Moto4_ID = 0x204,
    CAN_3510Moto5_ID = 0x205,
    CAN_3510Moto6_ID = 0x206,
    CAN_3510Moto7_ID = 0x207,
    CAN_3510Moto8_ID = 0x208,
    CAN_DriverPower_ID = 0x80,
    CAN_HeartBeat_ID = 0x156,
    SINGLE_GYRO_ID = 0x401,
} CAN_Message_ID;

/*接收到的云台电机的参数结构体*/

typedef struct
{
    int16_t speed_rpm = 0;
    int16_t real_current = 0;
    int16_t given_current = 0;
    uint16_t angle = 0; //abs angle range:[0,8191]
    uint16_t last_angle = 0;
    uint16_t offset_angle = 0;
    uint8_t hall = 0;

    int32_t round_cnt = 0;
    int32_t total_angle = 0;
    uint32_t msg_cnt = 0;

    int16_t power = 0;
} moto_measure_t;

////////////////陀螺仪结构体//////////////////////////////////////////////////

typedef struct
{
  float imu_yaw ;
  float imu_pit ;
  float imu_roll;
  float imu_yaw_g ;
  float imu_pit_g ;
  float imu_roll_g;
  float imu_yaw_a ;
  float imu_pit_a ;
  float imu_roll_a;
  float temp_yaw;
  float ax;
  float ay;
  float az;
} imu_t;

typedef struct{
	  float angle_yaw;
	  float angle_yawlast;
	  float angle_pit;
	  float angle_pitlast;
	  float angle_roll;
	  float angle_rolllast;
	  float total_yaw;
	  float total_pit;
	  float total_roll;
	  int16_t   angle_yaw_cnt;
}angle_t;

typedef struct
{
  float rc_vx ;
  float rc_vy ;
  float rc_vz ;

} ROS_RC;

typedef struct{
		float	 	position;
    float  	velocity;
    float   current;

	  float  position_last;
	  float     total_angle;
	  float     total_angle_last;	

		int32_t		round_cnt;
	
}Moto_Ak7010_t;

typedef struct{
		int16_t	 	position;
    int16_t  	velocity;
    int16_t   current;
}Moto_Dreame_t;


//////////////////////////////////////////////////////////////////

class RobotHardware
{
  public:
    RobotHardware();
    ~RobotHardware();

    /* HW Interface */
    moto_measure_t motors[HW_MOTOR_COUNT];
    moto_measure_t motors_can1[HW_MOTOR_COUNT];
    Moto_Ak7010_t Ak7010[2]={};
    Moto_Dreame_t Dreame_moto[6]={};
    imu_t imu_c={},imu_9={};
    angle_t imu_9_yaw;
    int16_t gyro_int16[3];
    int16_t accel_int16[8];
    float imu[4]={};
    float Ak7010_power[2]={};
    float RC_ADD[4]={},Yaw_offset_start=0;
    uint16_t  Dreame_angle,Dream_speed,Dreame_Torque;
    int run_time=0;
    int k_pos=0;
    float rc_set[6]={};//遥控器设定值
    int motion_angle[6]={};
    float RVIZ_K_POS=45.51;  //1 degree =45.51 
    float temp_goal0=0,temp_goal1=0,temp_goal2=0;
    // float temp_goal1=0;
    // float temp_goal2=0;
    float temp_goal3=0;
    float temp_goal4=0;
    float temp_goal5=0;
    float moto_set_k=4000,moto_set_p=6000,add_angle_speed=20;
    /* HW Receiver */
    void CAN0_ReceiveFrame(can_frame_t *frame);
    void CAN1_ReceiveFrame(can_frame_t *frame);
    void CanComm_ControlCmd(uint8_t id ,uint8_t cmd);
    void Dreame_CanComm_ControlCmd(uint8_t id,uint32_t Torque_Moto,uint16_t rad,uint16_t rads,uint16_t krad,uint16_t krads);
    void model3_CanComm_ControlCmd(uint8_t id );
    void model4_CanComm_ControlCmd(uint8_t id );

    /* HW Update */
    void update();

    uint8_t *p_imu0=(uint8_t*)&(imu_c.imu_yaw);
    uint8_t *p_imu1=(uint8_t*)&(imu_c.imu_pit);
    // uint8_t *p_imu0=(uint8_t*)&(imu[0]); //yaw
    // uint8_t *p_imu1=(uint8_t*)&(imu[1]); //pitch
  private:
    /* HW Adapter */
    SocketCAN can0_adapter;
    SocketCAN can1_adapter;
    /* Motor */
    void Motor_UpdateOffset(moto_measure_t *ptr, can_frame_t *frame);
    void CAN_Motor_Update();
    void Safe_CAN_Motor_Update();
    void MIT_CAN_Motor_Update(uint8_t set_id, float f_p, float f_v, float f_kp, float f_kd, float f_t);
};

//////////////////////////////Global Hardware Handle////////////////////////////////////

RobotHardware *Hardware();
void ReleaseHardware();

#endif