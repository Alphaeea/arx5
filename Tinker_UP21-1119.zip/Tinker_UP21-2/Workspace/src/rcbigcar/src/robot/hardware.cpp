#include "hardware.h"

//imu data

/////////////////////////Global HW Handle///////////////////////////////

RobotHardware *HW_Handle = NULL;

RobotHardware *Hardware()
{
    if (HW_Handle == NULL)
    {
        HW_Handle = new RobotHardware();
    }

    return HW_Handle;
}

void ReleaseHardware()
{
    if (HW_Handle == NULL)
    {
        return;
    }

    delete HW_Handle;
    HW_Handle = NULL;
}

//////////////////////////HW Update//////////////////////////////

void RobotHardware::update()
{
    // if(DBus_Use()->d_bus_data.s_r==DBus_Use()->d_bus_data.UP)
    // {
    // CAN_Motor_Update();
    // MIT_CAN_Motor_Update(0x01,0,0,0,0,Ak7010_power[0]);
    // MIT_CAN_Motor_Update(0x02,0,0,0,0,Ak7010_power[1]);
    // }
    // else
    // {
    // Safe_CAN_Motor_Update();
    // MIT_CAN_Motor_Update(0x01,0,0,0,0,0);
    // MIT_CAN_Motor_Update(0x02,0,0,0,0,0);
    // }
    //  Dreame_CanComm_ControlCmd(0x01,32768,31580,32768,10000,0);  //31580
    //  Dreame_CanComm_ControlCmd(0x02,32768,32042,32768,5000,0);
    //  Dreame_CanComm_ControlCmd(0x03,32768,30880,32768,5000,0);
    //  Dreame_CanComm_ControlCmd(0x04,60000,26916,32768,0,0);

    //  Dreame_CanComm_ControlCmd(0x01,32768,31580,32768,30000,0);  //31580
    //  Dreame_CanComm_ControlCmd(0x02,32768,40352,32768,40000,0);
    //  Dreame_CanComm_ControlCmd(0x03,32768,30880,32768,40000,0);
  // ROS_WARN("k_pos:%d",k_pos)
   // ROS_WARN("set_pos:%f",rc_set[2]);
     if(DBus_Use()->d_bus_data.s_r==DBus_Use()->d_bus_data.UP)
     {
    if(k_pos<6000)
    k_pos+=10;
    else if(k_pos<30000)
    k_pos+=1000;
    
    if(k_pos>27000)
    {
    rc_set[0]+=(DBus_Use()->d_bus_data.ch_l_x/660*45);
    rc_set[1]+=(DBus_Use()->d_bus_data.ch_l_y/660*45);
    rc_set[2]+=(DBus_Use()->d_bus_data.ch_r_y/660*45);
    rc_set[3]+=(DBus_Use()->d_bus_data.ch_r_x/660*45);
    // if(rc_set[2]>1145.727783)
    //     rc_set[2]=1145.727783;
    // if(rc_set[2]<-8196.919922)
    //     rc_set[2]=-8196.919922;   
    }

    // ROS_WARN("motion_angle:%f",motion_angle[4]);
    // ROS_WARN("rc_set:%f",rc_set[0]);
 
    // Dreame_CanComm_ControlCmd(0x01,32768,31580+rc_set[0]+RVIZ_K_POS*motion_angle[0],32768,k_pos,0);  //31580
    // Dreame_CanComm_ControlCmd(0x02,32768,40352+rc_set[1]+RVIZ_K_POS*motion_angle[1],32768,k_pos,0);
    // Dreame_CanComm_ControlCmd(0x03,32768,30880-rc_set[1]-rc_set[2]+RVIZ_K_POS*(motion_angle[2]-motion_angle[1]),32768,k_pos,0);
    // Dreame_CanComm_ControlCmd(0x04,32768,32768+rc_set[0]+RVIZ_K_POS*motion_angle[3],32768,4000,6000);
       //  temp_goal=0;
        if(temp_goal0>(RVIZ_K_POS*motion_angle[0]))
        temp_goal0-=add_angle_speed;
        else if(temp_goal0<(RVIZ_K_POS*motion_angle[0]))
        temp_goal0+=add_angle_speed;
        if(temp_goal1>(RVIZ_K_POS*motion_angle[1]))
        temp_goal1-=add_angle_speed;
        else if(temp_goal1<(RVIZ_K_POS*motion_angle[1]))
        temp_goal1+=add_angle_speed;
        if(temp_goal2>(RVIZ_K_POS*motion_angle[2]))
        temp_goal2-=add_angle_speed;
        else if(temp_goal2<(RVIZ_K_POS*motion_angle[2]))
        temp_goal2+=add_angle_speed;
        if(temp_goal3>(RVIZ_K_POS*motion_angle[3]))
        temp_goal3-=add_angle_speed;
        else if(temp_goal3<(RVIZ_K_POS*motion_angle[3]))
        temp_goal3+=add_angle_speed;
        if(temp_goal4>(RVIZ_K_POS*motion_angle[4]))
        temp_goal4-=add_angle_speed;
        else if(temp_goal4<(RVIZ_K_POS*motion_angle[4]))
        temp_goal4+=add_angle_speed;
        if(temp_goal5>(RVIZ_K_POS*motion_angle[5]))
        temp_goal5-=add_angle_speed;
        else if(temp_goal5<(RVIZ_K_POS*motion_angle[5]))
        temp_goal5+=add_angle_speed;

        // if(abs(temp_goal-(RVIZ_K_POS*motion_angle[0]))<200)
        // {
        //    // temp_goal= temp_goal+(temp_goal-(RVIZ_K_POS*motion_angle[0]))/100*5;


        // // ROS_WARN("motion_angle:%d",motion_angle[4]);     
        // k_pos=0;
        // Dreame_CanComm_ControlCmd(0x01,32768,31580+rc_set[0]+45.51*motion_angle[0],32768,k_pos,0);  //31580
        // Dreame_CanComm_ControlCmd(0x01,32768,32768+rc_set[0]+temp_goal0,32768,4000,6000);
        // Dreame_CanComm_ControlCmd(0x02,32768,40352+rc_set[1]+RVIZ_K_POS*motion_angle[1],32768,4000,6000);
        // Dreame_CanComm_ControlCmd(0x03,32768,30880-rc_set[1]-rc_set[2]+temp_goal1-temp_goal2,32768,4000,6000);
        // Dreame_CanComm_ControlCmd(0x04,32768,32768+rc_set[0]+temp_goal3,32768,4000,6000);
       // ROS_WARN("ch0:%f",rc_set[0]);
        Dreame_CanComm_ControlCmd(0x01,32768,32768-1196+rc_set[0]+temp_goal0,32768,moto_set_k,moto_set_p);
        Dreame_CanComm_ControlCmd(0x02,32768,32768-768+rc_set[1]-temp_goal1,32768,moto_set_k,moto_set_p);
        Dreame_CanComm_ControlCmd(0x03,32768,32768-6701-rc_set[1]-rc_set[2]+temp_goal1-temp_goal2,32768,20000,15000);
        Dreame_CanComm_ControlCmd(0x04,32768,32768+1574+rc_set[3]-temp_goal3,32768,moto_set_k,moto_set_p);

     }
     else //0
     {
       //  temp_goal=0;


        // if(abs(temp_goal-(RVIZ_K_POS*motion_angle[0]))<200)
        // {
        //    // temp_goal= temp_goal+(temp_goal-(RVIZ_K_POS*motion_angle[0]))/100*5;

// ID1 -1196 
// ID2 -768
// ID3 -6701
// ID4  1574
        // // ROS_WARN("motion_angle:%d",motion_angle[4]);     
        // k_pos=0;
        // Dreame_CanComm_ControlCmd(0x01,32768,31580+rc_set[0]+45.51*motion_angle[0],32768,k_pos,0);  //31580
        Dreame_CanComm_ControlCmd(0x01,32768,32768+1196+rc_set[0]+temp_goal0,32768,0,0);
        Dreame_CanComm_ControlCmd(0x02,32768,32768+768+rc_set[1]+RVIZ_K_POS*motion_angle[1],32768,0,0);
        Dreame_CanComm_ControlCmd(0x03,32768,32768+6701-rc_set[1]-rc_set[2]+temp_goal1-temp_goal2,32768,0,0);
        Dreame_CanComm_ControlCmd(0x04,32768,32768-1574+rc_set[0]+temp_goal3,32768,0,0);
        }
     }
//     Dreame_CanComm_ControlCmd(0x04,32768,26916,32768,10000,0);    



///////////////////////////HW Implementation/////////////////////////////

void CAN0_ReceiveHandlerProxy(can_frame_t *frame, void *ptr)
{
    ((RobotHardware *)ptr)->CAN0_ReceiveFrame(frame);
}

void CAN1_ReceiveHandlerProxy(can_frame_t *frame2, void *ptr)
{
    ((RobotHardware *)ptr)->CAN1_ReceiveFrame(frame2);
}

RobotHardware::RobotHardware()
{
    //Initialize HW
    can0_adapter.reception_handler_data = (void *)this;
    can0_adapter.reception_handler = &CAN0_ReceiveHandlerProxy;
    can0_adapter.open(HW_CAN0_ID);
    
    can1_adapter.reception_handler_data = (void *)this;
    can1_adapter.reception_handler = &CAN1_ReceiveHandlerProxy;
    can1_adapter.open("can1");
}

RobotHardware::~RobotHardware()
{
    can0_adapter.close();
    can1_adapter.close();
}


void RobotHardware::Motor_UpdateOffset(moto_measure_t *ptr, can_frame_t *frame)
{
    ptr->last_angle = ptr->angle;


    ptr->angle = (uint16_t)(frame->data[0] << 8 | frame->data[1] );
    ptr->real_current = (int16_t)(frame->data[2] << 8 | frame->data[3]);
    ptr->speed_rpm = ptr->real_current;
    ptr->given_current = (int16_t)(frame->data[4] << 8 | frame->data[5]) / -5;
    ptr->hall = frame->data[6];

    if (ptr->angle - ptr->last_angle > 4096)
        ptr->round_cnt--;
    else if (ptr->angle - ptr->last_angle < -4096)
        ptr->round_cnt++;

    ptr->total_angle = ptr->round_cnt * 8192 + ptr->angle - ptr->offset_angle;
}

void RobotHardware::CAN0_ReceiveFrame(can_frame_t *frame)
{
   // ROS_WARN("can_id:%d",(frame->can_id)& 0xFF00>>8);
    switch (((frame->can_id)& 0xFF00)>>8  )
    
    {
    case 0x01:
    {
        //int16_t Dreame_angle,Dream_speed,Dreame_Torque; 
        Dreame_angle  = (((frame->data[0] << 8) | (frame->data[1]) ));
        Dream_speed   = (((frame->data[2] << 8) | (frame->data[3]) ));
        Dreame_Torque = (((frame->data[4] << 8) | (frame->data[5]) ));
        Dreame_moto[0].position=Dreame_angle-32767;
        Dreame_moto[0].velocity=Dream_speed-32767;
        Dreame_moto[0].current=Dreame_Torque-32767;
       // ROS_WARN("Angle1:%d",Dreame_moto[0].position);
    } break;
    case 0x02:
    {
        Dreame_angle  = (((frame->data[0] << 8) | (frame->data[1]) ));
        Dream_speed   = (((frame->data[2] << 8) | (frame->data[3]) ));
        Dreame_Torque = (((frame->data[4] << 8) | (frame->data[5]) ));
        Dreame_moto[1].position=Dreame_angle-32767;
        Dreame_moto[1].velocity=Dream_speed-32767;
        Dreame_moto[1].current=Dreame_Torque-32767;
       // ROS_WARN("Angle2:%d",Dreame_moto[1].position);
        // ROS_WARN("Speed2:%d",Dreame_moto[1].velocity);
        // ROS_WARN("Torqu2:%d",Dreame_moto[1].current); 
       
    } break;
    case 0x03:
    {
        Dreame_angle  = (((frame->data[0] << 8) | (frame->data[1]) ));
        Dream_speed   = (((frame->data[2] << 8) | (frame->data[3]) ));
        Dreame_Torque = (((frame->data[4] << 8) | (frame->data[5]) ));
        Dreame_moto[2].position=Dreame_angle-32767;
        Dreame_moto[2].velocity=Dream_speed-32767;
        Dreame_moto[2].current=Dreame_Torque-32767;
       // ROS_WARN("Angle3:%d",Dreame_moto[2].position);
       
    } break;
    case 0x04:
    {
        Dreame_angle  = (((frame->data[0] << 8) | (frame->data[1]) ));
        Dream_speed   = (((frame->data[2] << 8) | (frame->data[3]) ));
        Dreame_Torque = (((frame->data[4] << 8) | (frame->data[5]) ));
        Dreame_moto[3].position=Dreame_angle-32767;
        Dreame_moto[3].velocity=Dream_speed-32767;
        Dreame_moto[3].current=Dreame_Torque-32767;
       // ROS_WARN("Angle4:%d",Dreame_moto[3].position);
        // ROS_WARN("Speed4:%d",Dreame_moto[3].velocity);
        // ROS_WARN("Torqu4:%d",Dreame_moto[3].current); 
       
    }break;
    
     default:
    break;
    // case CAN_3510Moto1_ID:
    // case CAN_3510Moto2_ID:
    // case CAN_3510Moto3_ID:
    // case CAN_3510Moto4_ID:
    // case CAN_3510Moto5_ID:
    // case CAN_3510Moto6_ID:
    // case CAN_3510Moto7_ID:
    // case CAN_3510Moto8_ID:

    // {
    //     int idx = frame->can_id - CAN_3510Moto1_ID; //first 8 motors

    //     if (idx < HW_MOTOR_COUNT)
    //     {
    //         Motor_UpdateOffset(&motors[idx], frame);
    //         motors[idx].msg_cnt++;
    //     }
    //     // ROS_WARN("test %d ",motors[0].total_angle);

    //     break;
    // }

    //     case 0x501:
    //     {
    //         p_imu0[0]=frame->data[0];
    //         p_imu0[1]=frame->data[1];
    //         p_imu0[2]=frame->data[2];
    //         p_imu0[3]=frame->data[3];

    //         p_imu1[0]=frame->data[4];
    //         p_imu1[1]=frame->data[5];
    //         p_imu1[2]=frame->data[6];
    //         p_imu1[3]=frame->data[7];
    //        // ROS_WARN("imu_c:%f",imu[0]);
    //     //ROS_WARN("imu_c:%f",Hardware()->imu[0]);
    //     } break;


    }
}


float uint_to_float1(int x_int, float x_min, float x_max, int bits){
    /// converts unsigned int to float, given range and number of bits ///
    float span = x_max - x_min;
    float offset = x_min;
    return ((float)x_int)*span/((float)((1<<bits)-1)) + offset;
    }

void RobotHardware::CAN1_ReceiveFrame(can_frame_t *frame)
{
    
	if(frame->data[0]==0x01)
	{
	//	float p;
	Ak7010[0].position_last=Ak7010[0].position;
    //int id = _hcan->pRxMsg->Data[0];
    int p_int = (frame->data[1]<<8)|frame->data[2];
    int v_int = (frame->data[3]<<4)|(frame->data[4]>>4);
    int i_int = ((frame->data[4]&0xF)<<8)|frame->data[5];
    /// convert ints to floats ///
    float p = uint_to_float1(p_int, P_MIN, P_MAX, 16);
    float v = uint_to_float1(v_int, V_MIN, V_MAX, 12);
    float i = uint_to_float1(i_int, -40, 40, 12);
		Ak7010[0].position=p+12.5f;
		Ak7010[0].velocity=v;
		Ak7010[0].current=i;		

		if(Ak7010[0].position - Ak7010[0].position_last > 12.5f)  //编码器最大值一半
		Ak7010[0].round_cnt --;
		else if (Ak7010[0].position - Ak7010[0].position_last < -12.5f)
		Ak7010[0].round_cnt ++;
		Ak7010[0].total_angle = Ak7010[0].round_cnt * 25.0f + Ak7010[0].position;		 //编码器最大值		
	}


	if(frame->data[0]==0x02)
	{
	//	float p;
	Ak7010[1].position_last=Ak7010[1].position;
    //int id = _hcan->pRxMsg->Data[0];
    int p_int = (frame->data[1]<<8)|frame->data[2];
    int v_int = (frame->data[3]<<4)|(frame->data[4]>>4);
    int i_int = ((frame->data[4]&0xF)<<8)|frame->data[5];
    /// convert ints to floats ///
    float p = uint_to_float1(p_int, P_MIN, P_MAX, 16);
    float v = uint_to_float1(v_int, V_MIN, V_MAX, 12);
    float i = uint_to_float1(i_int, -40, 40, 12);
		Ak7010[1].position=p+12.5f;
		Ak7010[1].velocity=v;
		Ak7010[1].current=i;		

		if(Ak7010[1].position - Ak7010[1].position_last > 12.5f)  //编码器最大值一半
		Ak7010[1].round_cnt --;
		else if (Ak7010[1].position - Ak7010[1].position_last < -12.5f)
		Ak7010[1].round_cnt ++;
		Ak7010[1].total_angle = Ak7010[1].round_cnt * 25.0f + Ak7010[1].position;		 //编码器最大值		

    //ROS_WARN("AK7010:%f",Ak7010[1].velocity);
	}


   switch (frame->can_id)
    {
    case CAN_3510Moto1_ID:
    case CAN_3510Moto2_ID:
    case CAN_3510Moto3_ID:
    case CAN_3510Moto4_ID:
    case CAN_3510Moto5_ID:
    case CAN_3510Moto6_ID:
    case CAN_3510Moto7_ID:
    case CAN_3510Moto8_ID:

    {
        int idx = frame->can_id - CAN_3510Moto1_ID; //first 8 motors

        if (idx < HW_MOTOR_COUNT)
        {
            Motor_UpdateOffset(&motors_can1[idx], frame);
            motors_can1[idx].msg_cnt++;
        }
        //  ROS_WARN("test %d ",motors_can1[0].total_angle);

        break;
    }
      //九轴陀螺仪
	  	case 0x401: //弧度
		{
			
		    imu_9_yaw.angle_yawlast = imu_9_yaw.angle_yaw;	
			
			imu_9.temp_yaw=0.0001f * ((int16_t)(frame->data[1]<<8) |(frame->data[0])); 
			imu_9.imu_pit=0.0001f * ((int16_t)(frame->data[3]<<8) |(frame->data[2])); 
			imu_9.imu_roll=0.0001f * ((int16_t)(frame->data[5]<<8) |(frame->data[4])); 

			imu_9_yaw.angle_yaw = imu_9.temp_yaw+M_PI;
				
			if(imu_9_yaw.angle_yaw - imu_9_yaw.angle_yawlast < -M_PI)  imu_9_yaw.angle_yaw_cnt++;
			else if(imu_9_yaw.angle_yaw - imu_9_yaw.angle_yawlast > M_PI) imu_9_yaw.angle_yaw_cnt--;
			
			imu_9.imu_yaw=	imu_9_yaw.angle_yaw_cnt*2.000f*M_PI + imu_9_yaw.angle_yaw	;			
		}
			break;
				case 0x402:
		{
			memcpy(gyro_int16, frame->data,6);  //rad/s
			imu_9.imu_roll_g=gyro_int16[0]*0.00106526443603169529841533860381f;
			imu_9.imu_pit_g=gyro_int16[1]*0.00106526443603169529841533860381f; //对应PITCH  //-11.0137 0.00053263221801584764920766930190693f
			imu_9.imu_yaw_g=gyro_int16[2]*0.00106526443603169529841533860381f; //对应YAW
		}
		  break ;

			case 0x403 :
		{
			memcpy(accel_int16, frame->data,6);  //rad/s		
			imu_9.ax= (accel_int16[0] *0.0008974358974f);    //前后
			imu_9.ay= (accel_int16[1] *0.0008974358974f);    //左右
			imu_9.az= (accel_int16[2] *0.0008974358974f);    //上下			
		}
		  break ;
          
        case 0x501:
        {
            p_imu0[0]=frame->data[0];
            p_imu0[1]=frame->data[1];
            p_imu0[2]=frame->data[2];
            p_imu0[3]=frame->data[3];

            p_imu1[0]=frame->data[4];
            p_imu1[1]=frame->data[5];
            p_imu1[2]=frame->data[6];
            p_imu1[3]=frame->data[7];
           // ROS_WARN("imu_c:%f",imu[0]);
       // ROS_WARN("imu_c:%f",imu_c.imu_yaw);
        } break;


    }

}

void RobotHardware::CAN_Motor_Update()
    {
    can_frame_t frame;
    //CAN0 Transmit Frame 1
    frame.can_id = HW_CAN_MOTOR_ID_1;
   // frame.can_id = 0x701;
    frame.can_dlc = 8;
    // ROS to  STM32 CAN  test
    for (int id = 0; id < 4; id++)
    {
        int16_t power = motors[id].power ;
        frame.data[2 * id] = (uint8_t)(power >> 8);
        frame.data[2 * id + 1] = (uint8_t)(power);

       // ROS_WARN("%d",motors[0].power);
    }
     
    //d_bus_data_.
    if (can0_adapter.is_open()) can0_adapter.transmit(&frame);
    if (can1_adapter.is_open()) can1_adapter.transmit(&frame);


    }

void RobotHardware::Safe_CAN_Motor_Update()
    {
    can_frame_t frame;
    //CAN0 Transmit Frame 1
    frame.can_id = HW_CAN_MOTOR_ID_1;
   // frame.can_id = 0x701;
    frame.can_dlc = 8;
    // ROS to  STM32 CAN  test
    for (int id = 0; id < 4; id++)
    {
        int16_t power = 0 ;
        frame.data[2 * id] = (uint8_t)(power >> 8);
        frame.data[2 * id + 1] = (uint8_t)(power);

       // ROS_WARN("%d",motors[0].power);
    }
     
    //d_bus_data_.
    if (can0_adapter.is_open()) can0_adapter.transmit(&frame);
    if (can1_adapter.is_open()) can1_adapter.transmit(&frame);


    }    

static uint16_t float_to_uint(float x, float x_min, float x_max, uint8_t bits)
{
    float span = x_max - x_min;
    float offset = x_min;
    return (uint16_t) ((x-offset)*((float)((1<<bits)-1))/span);
}


void RobotHardware::MIT_CAN_Motor_Update(uint8_t set_id, float f_p, float f_v, float f_kp, float f_kd, float f_t)
    {
    uint16_t p, v, kp, kd, t;
    
    LIMIT_MIN_MAX(f_p,  P_MIN,  P_MAX);
    LIMIT_MIN_MAX(f_v,  V_MIN,  V_MAX);
    LIMIT_MIN_MAX(f_kp, KP_MIN, KP_MAX);
    LIMIT_MIN_MAX(f_kd, KD_MIN, KD_MAX);
    LIMIT_MIN_MAX(f_t,  T_MIN,  T_MAX);
    
    p = float_to_uint(f_p,      P_MIN,  P_MAX,  16);            
    v = float_to_uint(f_v,      V_MIN,  V_MAX,  12);
    kp = float_to_uint(f_kp,    KP_MIN, KP_MAX, 12);
    kd = float_to_uint(f_kd,    KD_MIN, KD_MAX, 12);
    t = float_to_uint(f_t,      T_MIN,  T_MAX,  12);

    can_frame_t frame;
    //CAN0 Transmit Frame 1
    frame.can_id = set_id;
   // frame.can_id = 0x701;
    frame.can_dlc = 8;
    // ROS to  STM32 CAN  test
		frame.data[0] = p>>8;
		frame.data[1] = p&0xFF;
		frame.data[2] = v>>4;
		frame.data[3] = ((v&0xF)<<4)|(kp>>8);
		frame.data[4] = kp&0xFF;
		frame.data[5] = kd>>4;
		frame.data[6] = ((kd&0xF)<<4)|(t>>8);
		frame.data[7] = t&0xff;
     
    if (can1_adapter.is_open()) can1_adapter.transmit(&frame);

    }

void RobotHardware::CanComm_ControlCmd(uint8_t id ,uint8_t cmd)
{
		uint8_t buf[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, cmd}; //0xFC

        can_frame_t frame;
        //CAN0 Transmit Frame 1
        frame.can_id = id;
         // frame.can_id = 0x701;
        frame.can_dlc = 8;
        // ROS to  STM32 CAN  test
		frame.data[0] = buf[0];
		frame.data[1] = buf[1];
		frame.data[2] = buf[2];
		frame.data[3] = buf[3];
		frame.data[4] = buf[4];
		frame.data[5] = buf[5];
		frame.data[6] = buf[6];
		frame.data[7] = buf[7];
     
    if (can1_adapter.is_open()) can1_adapter.transmit(&frame);


}

void RobotHardware::model3_CanComm_ControlCmd(uint8_t id )
{
        int32_t CAN_Master_ID=0x01;
        can_frame_t frame;
        frame.can_id = (CAN_EFF_FLAG | (0x03U << 24) | (CAN_Master_ID << 8) | id);
        frame.can_dlc = 8;

		frame.data[0] = 1;
		frame.data[1] = 0;
		frame.data[2] = 0;
		frame.data[3] = 0;
		frame.data[4] = 0;
		frame.data[5] = 0;
		frame.data[6] = 0;
		frame.data[7] = 0;
     
    if (can0_adapter.is_open()) can0_adapter.transmit(&frame);


}

void RobotHardware::model4_CanComm_ControlCmd(uint8_t id )
{
        int32_t CAN_Master_ID=0x01;
        can_frame_t frame;
        frame.can_id = (CAN_EFF_FLAG | (0x04U << 24) | (CAN_Master_ID << 8) | id);
        frame.can_dlc = 8;

		frame.data[0] = 0;
		frame.data[1] = 0;
		frame.data[2] = 0;
		frame.data[3] = 0;
		frame.data[4] = 0;
		frame.data[5] = 0;
		frame.data[6] = 0;
		frame.data[7] = 0;
     
    if (can0_adapter.is_open()) can0_adapter.transmit(&frame);


}

void RobotHardware::Dreame_CanComm_ControlCmd(uint8_t id, uint32_t Torque_Moto,uint16_t rad,uint16_t rads,uint16_t krad,uint16_t krads)
{
        // int32_t Torque_Moto=32768;
        
        can_frame_t frame;
        // int16_t rad=40000;
        // int16_t rads=0;
        // int16_t krad=1;
        // int16_t krads=0;

        frame.can_id = (CAN_EFF_FLAG|(0x01<<24)|(Torque_Moto<<8)|(id));
        frame.can_dlc = 8;

		frame.data[0] = rad>>8;
		frame.data[1] = rad;
		frame.data[2] = rads>>8;
		frame.data[3] = rads;
		frame.data[4] = krad>>8;
		frame.data[5] = krad;
		frame.data[6] = krads>>8;
		frame.data[7] = krads;
     
    if (can0_adapter.is_open()) can0_adapter.transmit(&frame);


}